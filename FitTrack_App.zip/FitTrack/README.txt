FitTrack — Personal Fitness Tracker

HOW TO USE
1. Open index.html in a modern browser (Chrome, Edge, Safari, or Firefox).
2. Log workouts by exercise, sets, reps, and weight.
3. Record body-weight entries to view a trend chart.
4. Add a weekly progress photo and select Front, Side, or Back.
5. Use Progress to review summaries and Export backup to download your records.

DATA & PRIVACY
Workout and body-weight entries are stored in this browser's local storage. Photos are stored in this browser's IndexedDB database on this device. The app does not upload your data to a server and does not sync between devices. Export backups regularly. Clearing browser site data may erase app data. This app is a standalone starter app, not a medical device.

INSTALL TIP
On iPhone, host the files on a secure static website to use Safari's Share > Add to Home Screen. Opening a local HTML file directly can have browser storage limitations. The app's core features work offline after the file is available, but camera/file access and storage behavior depend on the browser.
